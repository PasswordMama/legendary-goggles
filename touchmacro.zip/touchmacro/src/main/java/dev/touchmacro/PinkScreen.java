package dev.touchmacro;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;

/** Base for all TouchMacro screens: animated Rose Glass background + panel, slide-and-fade open. */
public abstract class PinkScreen extends Screen {
    protected int px, py, pw, ph;
    private final long opened = System.currentTimeMillis();
    private float slide = 0f;

    protected PinkScreen(Text title) { super(title); }

    protected void layoutPanel(int panelW, int panelH) {
        pw = Math.min(this.width - 12, panelW);
        ph = panelH;
        px = (this.width - pw) / 2;
        py = Math.max(4, (this.height - ph) / 2);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Matrix3x2fStack m = ctx.getMatrices();
        // the page slides up on open, but the backdrop itself stays put
        m.pushMatrix();
        m.translate(0f, -slide);
        Ui.drawBackground(ctx, this.width, this.height);
        m.popMatrix();
        Ui.panel(ctx, px, py, pw, ph);
        drawPanel(ctx);
    }

    /** Drawn on the panel, under the widgets. */
    protected void drawPanel(DrawContext ctx) {}

    /** Drawn after the widgets. */
    protected void drawOverlay(DrawContext ctx) {}

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        float t = Math.min(1f, (System.currentTimeMillis() - opened) / 340f);
        float e = 1f - (1f - t) * (1f - t) * (1f - t);   // ease-out cubic
        Ui.fade = e;
        slide = (1f - e) * 16f;
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(0f, slide);
        super.render(ctx, mouseX, mouseY, delta);
        drawOverlay(ctx);
        // credit line (only when there is room below the panel and status text)
        if (this.height - 12 >= py + ph + 20)
            Ui.centered(ctx, "AshieCloud's Macro  •  by AshieCloud045 (Discord)", this.width / 2, this.height - 12, 0xAAFFE3F0);
        m.popMatrix();
        Ui.fade = 1f;
    }

    @Override
    public boolean shouldPause() { return false; }
}
