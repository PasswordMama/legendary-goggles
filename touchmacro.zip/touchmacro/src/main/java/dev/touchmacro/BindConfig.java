package dev.touchmacro;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;

public class BindConfig {
    public static final String[] NAMES = {"Open GUI", "Record / Stop", "Play / Stop"};
    /** GLFW key codes, -1 = unbound. */
    public static int[] keys = {GLFW.GLFW_KEY_F8, GLFW.GLFW_KEY_F9, GLFW.GLFW_KEY_F10};
    /** Every N loops do a random 2-block wander and return. 0 = off. */
    public static int wanderEvery = 0;

    // What to record AND replay
    public static final int T_MOVE = 0, T_MINE = 1, T_USE = 2, T_LOOK = 3,
            T_HOTBAR = 4, T_INV = 5, T_CHAT = 6, T_CMD = 7;
    public static final String[] TOGGLE_NAMES = {
            "Walk/Jump/Sneak", "Mine/Attack", "Use/Place", "Camera look",
            "Hotbar slot", "Inventory & menus", "Chat messages", "Commands"};
    public static boolean[] toggles = {true, true, true, true, true, true, true, true};

    /** Graphics quality: 0 Low (fewest draw calls), 1 Balanced, 2 Full. Tuned for phones / MobileGlues. */
    public static int quality = 1;
    /** Use the bundled Poppins font (needs FreeType; falls back to the normal font if off). */
    public static boolean fancyFont = true;
    public static final String[] QUALITY_NAMES = {"Low", "Balanced", "Full"};

    public static boolean on(int t) { return toggles[t]; }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static class Store { int[] keys; int wanderEvery; boolean[] toggles; int quality = 1; boolean fancyFont = true; }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("touchmacro").resolve("binds.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Store s = GSON.fromJson(Files.readString(f), Store.class);
                if (s == null) return;
                if (s.keys != null && s.keys.length == keys.length) keys = s.keys;
                wanderEvery = Math.max(0, s.wanderEvery);
                if (s.toggles != null && s.toggles.length == toggles.length) toggles = s.toggles;
                quality = Math.max(0, Math.min(2, s.quality));
                fancyFont = s.fancyFont;
            }
        } catch (Exception e) {
            System.err.println("[TouchMacro] could not load config: " + e);
        }
    }

    public static void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Store s = new Store();
            s.keys = keys;
            s.wanderEvery = wanderEvery;
            s.toggles = toggles;
            s.quality = quality;
            s.fancyFont = fancyFont;
            Files.writeString(f, GSON.toJson(s));
        } catch (Exception e) {
            System.err.println("[TouchMacro] could not save config: " + e);
        }
    }
}
