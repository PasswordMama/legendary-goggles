package dev.touchmacro;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class MacroScreen extends PinkScreen {
    private static final int PAD = 12, GAP = 6, ROW = 22;

    private TextFieldWidget nameField;
    private List<String> names = new ArrayList<>();
    private int sel = 0;
    private String status = "";
    private long statusAt = 0L;
    private PinkSlider speedSlider;
    private int speedY;

    private int x0, innerW, headerY, wanderY, saveY, pickY;
    private int labelX, labelW;

    public MacroScreen() { super(Text.literal("AshieCloud's Macro")); }

    @Override
    protected void init() {
        names = MacroManager.list();
        if (sel >= names.size()) sel = 0;

        int ph0 = PAD + 16 + GAP + ROW + GAP + 20 + GAP + 20 + GAP + ROW + GAP + ROW + GAP + ROW + PAD;
        layoutPanel(360, ph0);
        x0 = px + PAD;
        innerW = pw - PAD * 2;
        int y = py + PAD;
        headerY = y;
        y += 16 + GAP;

        // Row 1: Record / Stop / Play / Loop
        int bw = (innerW - 3 * 4) / 4;
        addDrawableChild(new PinkButton(x0, y, bw, ROW, Text.literal("Record"), true, b -> {
            this.client.setScreen(null);
            MacroManager.startRecording(this.client);
        }));
        addDrawableChild(new PinkButton(x0 + (bw + 4), y, bw, ROW, Text.literal("Stop"), false, b -> {
            MacroManager.stopAll(this.client);
            setStatus("Stopped.");
        }));
        addDrawableChild(new PinkButton(x0 + 2 * (bw + 4), y, bw, ROW, Text.literal("Play"), true, b -> {
            this.client.setScreen(null);
            MacroManager.startPlayback(this.client);
        }));
        PinkButton loopBtn = new PinkButton(x0 + 3 * (bw + 4), y, bw, ROW, Text.literal("Loop"), false, b -> {
            MacroManager.loop = !MacroManager.loop;
            ((PinkButton) b).sw = MacroManager.loop;
        });
        loopBtn.sw = MacroManager.loop;
        addDrawableChild(loopBtn);
        y += ROW + GAP;

        // Row 2: playback speed for the loaded macro: [-] [slider] [+] [1x]
        speedY = y;
        int sb = 26, rb = 34;
        int sliderW = innerW - sb * 2 - rb - GAP * 3;
        speedSlider = new PinkSlider(x0 + sb + GAP, y, sliderW, 20, v -> MacroManager.setSpeed(v));
        speedSlider.setValue(MacroManager.getSpeed());
        speedSlider.active = MacroManager.current != null;
        addDrawableChild(speedSlider);
        addDrawableChild(new PinkButton(x0, y, sb, 20, Text.literal("-"), false, b -> nudgeSpeed(-1)));
        addDrawableChild(new PinkButton(x0 + sb + GAP + sliderW + GAP, y, sb, 20, Text.literal("+"), false, b -> nudgeSpeed(1)));
        addDrawableChild(new PinkButton(x0 + innerW - rb, y, rb, 20, Text.literal("1x"), false, b -> {
            if (MacroManager.current == null) { setStatus("Load or record a macro first."); return; }
            MacroManager.setSpeed(1f);
            speedSlider.setValue(1f);
        }));
        y += 20 + GAP;

        // Row 3: wander stepper
        wanderY = y;
        addDrawableChild(new PinkButton(x0, y, 28, 20, Text.literal("-"), false, b -> {
            BindConfig.wanderEvery = Math.max(0, BindConfig.wanderEvery - 1);
            BindConfig.save();
        }));
        addDrawableChild(new PinkButton(x0 + innerW - 28, y, 28, 20, Text.literal("+"), false, b -> {
            BindConfig.wanderEvery = Math.min(999, BindConfig.wanderEvery + 1);
            BindConfig.save();
        }));
        y += 20 + GAP;

        // Row 4: name field + Save
        saveY = y;
        int saveW = 84;
        nameField = new TextFieldWidget(this.textRenderer, x0 + 12, y + (ROW - 8) / 2,
                innerW - saveW - GAP - 24, 10, Text.literal("name"));
        nameField.setDrawsBackground(false);
        nameField.setMaxLength(32);
        String def = MacroManager.currentName.isEmpty() || MacroManager.currentName.startsWith("(")
                ? "macro" + (names.size() + 1) : MacroManager.currentName;
        nameField.setText(def);
        addDrawableChild(nameField);
        addDrawableChild(new PinkButton(x0 + innerW - saveW, y, saveW, ROW, Text.literal("Save"), true, b -> {
            boolean ok = MacroManager.save(nameField.getText());
            setStatus(ok ? "Saved as " + MacroManager.sanitize(nameField.getText()) : "Nothing to save.");
            names = MacroManager.list();
        }));
        y += ROW + GAP;

        // Row 5: < name > Load Delete
        pickY = y;
        int ab = 26, lw = 52;
        labelW = innerW - ab * 2 - lw * 2 - GAP * 4;
        labelX = x0 + ab + GAP;
        addDrawableChild(new PinkButton(x0, y, ab, ROW, Text.literal("<"), false, b -> {
            if (!names.isEmpty()) sel = (sel - 1 + names.size()) % names.size();
        }));
        addDrawableChild(new PinkButton(labelX + labelW + GAP, y, ab, ROW, Text.literal(">"), false, b -> {
            if (!names.isEmpty()) sel = (sel + 1) % names.size();
        }));
        int bx = labelX + labelW + GAP + ab + GAP;
        addDrawableChild(new PinkButton(bx, y, lw, ROW, Text.literal("Load"), false, b -> {
            if (names.isEmpty()) { setStatus("No saved macros."); return; }
            MacroManager.flushSpeed();
            setStatus(MacroManager.load(names.get(sel)) ? "Loaded " + names.get(sel) : "Load failed.");
            speedSlider.active = MacroManager.current != null;
            speedSlider.setValue(MacroManager.getSpeed());
        }));
        addDrawableChild(new PinkButton(bx + lw + GAP, y, lw, ROW, Text.literal("Delete"), false, b -> {
            if (names.isEmpty()) return;
            MacroManager.delete(names.get(sel));
            setStatus("Deleted " + names.get(sel));
            names = MacroManager.list();
            sel = 0;
        }));
        y += ROW + GAP;

        // Row 6: Binds / Options / Done
        int tw = (innerW - 2 * GAP) / 3;
        addDrawableChild(new PinkButton(x0, y, tw, ROW, Text.literal("Binds"), false, b ->
                this.client.setScreen(new BindsScreen(this))));
        addDrawableChild(new PinkButton(x0 + tw + GAP, y, tw, ROW, Text.literal("Options"), false, b ->
                this.client.setScreen(new OptionsScreen(this))));
        addDrawableChild(new PinkButton(x0 + 2 * (tw + GAP), y, tw, ROW, Text.literal("Done"), true, b ->
                this.client.setScreen(null)));
    }

    private void setStatus(String s) {
        status = s;
        statusAt = System.currentTimeMillis();
    }

    private void nudgeSpeed(int dir) {
        if (MacroManager.current == null) { setStatus("Load or record a macro first."); return; }
        float v = MacroManager.getSpeed();
        float step = (dir < 0 ? v <= 1.001f : v < 1f) ? 0.05f : 0.1f;
        MacroManager.setSpeed(v + dir * step);
        speedSlider.setValue(MacroManager.getSpeed());
    }

    @Override
    public void removed() {
        MacroManager.flushSpeed();
        super.removed();
    }

    @Override
    protected void drawPanel(DrawContext ctx) {
        // title with a gentle colour pulse
        float pulse = (float) (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 700.0));
        Ui.left(ctx, "AshieCloud's Macro", x0, headerY + 2, Ui.lerp(0xFFFFFFFF, 0xFFFFC9E3, pulse), true);

        String cur = MacroManager.current == null ? "no macro loaded"
                : MacroManager.currentName + " - " + MacroManager.current.length() + " ticks";
        int maxCur = innerW - Ui.width("AshieCloud's Macro", true) - 22;
        while (cur.length() > 6 && Ui.width(cur, false) + 14 > maxCur) cur = cur.substring(0, cur.length() - 2) + "…";
        int cw = Ui.width(cur, false) + 14;
        Ui.roundRect(ctx, x0 + innerW - cw, headerY, cw, 14, 7, 0x2EFFFFFF);
        Ui.left(ctx, cur, x0 + innerW - cw + 7, headerY + 3, 0xFFFFE3F0);

        // field pill behind the text box
        Ui.roundRect(ctx, x0, saveY, innerW - 84 - GAP, ROW, ROW / 2, 0x29FFFFFF);
        Ui.roundOutline(ctx, x0, saveY, innerW - 84 - GAP, ROW, ROW / 2, 0x4DFFFFFF);
        // macro name pill
        Ui.roundRect(ctx, labelX, pickY, labelW, ROW, ROW / 2, 0x1AFFFFFF);
    }

    @Override
    protected void drawOverlay(DrawContext ctx) {
        int n = BindConfig.wanderEvery;
        String w = n == 0 ? "Wander: OFF" : "Wander 2 blocks every " + n + " loop" + (n == 1 ? "" : "s");
        Ui.centered(ctx, w, x0 + innerW / 2, wanderY + 6, 0xFFFFFFFF);

        String s = names.isEmpty() ? "no saved macros" : names.get(sel) + "  " + (sel + 1) + "/" + names.size();
        Ui.centered(ctx, s, labelX + labelW / 2, pickY + (ROW - 8) / 2, 0xFFFFFFFF);

        // status message: fades in, stays, fades out
        if (!status.isEmpty()) {
            float age = (System.currentTimeMillis() - statusAt) / 1000f;
            float al = Math.min(1f, age * 6f) * Math.min(1f, Math.max(0f, 3.5f - age) * 2f);
            if (al > 0.02f) {
                int col = ((int) (255 * al) << 24) | 0xFFE3F0;
                Ui.centered(ctx, status, this.width / 2, py + ph + 8 - Math.round((1f - Math.min(1f, age * 6f)) * 4f), col);
            }
        }
    }
}
