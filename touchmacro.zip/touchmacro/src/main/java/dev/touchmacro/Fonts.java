package dev.touchmacro;

import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;

/**
 * Gives out Text drawn with the bundled Poppins font (assets/touchmacro/font/ui*.json).
 * Built through the text codec so it does not depend on Style/font API details;
 * if anything goes wrong it quietly falls back to the normal Minecraft font.
 */
public final class Fonts {
    private Fonts() {}

    private static final Map<String, Text> CACHE = new HashMap<>();

    public static void clearCache() { CACHE.clear(); }

    public static Text ui(String s, boolean bold) {
        if (!BindConfig.fancyFont) {
            Text plain = Text.literal(s);
            return bold ? plain.copy().formatted(Formatting.BOLD) : plain;
        }
        String key = (bold ? "b|" : "r|") + s;
        Text t = CACHE.get(key);
        if (t != null) return t;
        Text fallback = Text.literal(s);
        try {
            JsonObject o = new JsonObject();
            o.addProperty("text", s);
            o.addProperty("font", bold ? "touchmacro:ui_bold" : "touchmacro:ui");
            t = TextCodecs.CODEC.parse(JsonOps.INSTANCE, o).result().orElse(fallback);
        } catch (Throwable e) {
            t = fallback;
        }
        if (CACHE.size() > 400) CACHE.clear();
        CACHE.put(key, t);
        return t;
    }
}
