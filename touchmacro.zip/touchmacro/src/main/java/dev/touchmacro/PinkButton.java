package dev.touchmacro;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import org.joml.Matrix3x2fStack;

/**
 * Rose Glass pill button: glass or pink gradient. Everything eases smoothly:
 * hover grows + lifts the pill and brightens the label, a click gives a soft squish-and-bounce
 * plus a light flash, and the on/off switch knob slides.
 */
public class PinkButton extends ClickableWidget {
    public interface PressAction { void onPress(PinkButton button); }

    public boolean primary;
    /** null = no switch; otherwise draws an on/off switch on the right. */
    public Boolean sw = null;

    private float hov = 0f;      // 0..1 hover amount (eased)
    private float knob = -1f;    // 0..1 switch knob position (eased)
    private long flash = -100000L;
    private long lastNs = System.nanoTime();
    private final PressAction action;

    public PinkButton(int x, int y, int w, int h, net.minecraft.text.Text msg, boolean primary, PressAction action) {
        super(x, y, w, h, msg);
        this.primary = primary;
        this.action = action;
    }

    @Override
    public void onClick(Click click, boolean doubled) {
        flash = System.currentTimeMillis();
        action.onPress(this);
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        this.appendDefaultNarrations(builder);
    }

    @Override
    public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long nowNs = System.nanoTime();
        float dt = Math.min(0.08f, (nowNs - lastNs) / 1_000_000_000f);
        lastNs = nowNs;

        hov = Ui.approach(hov, (this.isHovered() && this.active) ? 1f : 0f, 16f, dt);
        float swTarget = (sw != null && sw) ? 1f : 0f;
        knob = knob < 0f ? swTarget : Ui.approach(knob, swTarget, 18f, dt);

        float p = (System.currentTimeMillis() - flash) / 380f;          // click animation 0..1
        float fl = Math.max(0f, 1f - p * 1.6f);                          // light flash
        float bump = 0f;                                                 // squish then overshoot
        if (p >= 0f && p < 1f) bump = (float) (Math.exp(-4.5 * p) * Math.cos(p * 11.0));
        float lit = Math.max(hov * 0.85f, fl);

        boolean fx = BindConfig.quality >= 1;
        float scale = fx ? 1f + 0.03f * hov - 0.06f * bump : 1f;
        float lift = fx ? -1.5f * hov : 0f;

        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        int r = h / 2;
        Matrix3x2fStack m = ctx.getMatrices();
        float cx = x + w / 2f, cy = y + h / 2f;
        if (fx) {
            m.pushMatrix();
            m.translate(cx, cy + lift);
            m.scale(scale, scale);
            m.translate(-cx, -cy);
        }

        if (!this.active) {
            Ui.roundRect(ctx, x, y, w, h, r, 0x14FFFFFF);
            Ui.roundOutline(ctx, x, y, w, h, r, 0x26FFFFFF);
        } else if (primary) {
            int ga = (int) (0x30 + 0x30 * lit);                         // glow gets stronger on hover
            Ui.roundRect(ctx, x + 1, y + 3, w - 2, h, r, (ga << 24) | 0xE23A85);
            if (BindConfig.quality >= 2 && lit > 0.05f) Ui.roundRect(ctx, x - 1, y + 1, w + 2, h + 2, r + 1, ((int) (0x26 * lit) << 24) | 0xFF9CCB);
            Ui.roundGradient(ctx, x, y, w, h, r,
                    Ui.lerp(0xFFE23A85, 0xFFFF70B0, lit), Ui.lerp(0xFFC71F6E, 0xFFE0408A, lit));
            Ui.roundOutline(ctx, x, y, w, h, r, Ui.lerp(0x88FFFFFF, 0xDDFFFFFF, lit));
            // glossy top highlight
            Ui.roundRect(ctx, x + r / 2, y + 1, w - r, 1, 0, 0x33FFFFFF);
        } else {
            Ui.roundRect(ctx, x, y, w, h, r, Ui.lerp(0x29FFFFFF, 0x52FFFFFF, lit));
            Ui.roundOutline(ctx, x, y, w, h, r, Ui.lerp(0x4DFFFFFF, 0xAAFFFFFF, lit));
        }

        int textColor = this.active ? Ui.lerp(0xFFF1DCEA, 0xFFFFFFFF, lit) : 0x88FFFFFF;
        float textCx = x + w / 2f;
        if (sw != null) {
            textCx = x + (w - 26) / 2f;
            int sx = x + w - 28, sy = y + (h - 10) / 2;
            Ui.roundRect(ctx, sx, sy, 20, 10, 5, Ui.lerp(0x66FFFFFF, 0xFFFFFFFF, knob));
            int kx = sx + 1 + Math.round(10 * knob);
            Ui.roundRect(ctx, kx, sy + 1, 8, 8, 4, Ui.lerp(0xFFFFFFFF, 0xFFD62A74, knob));
        }
        Ui.centeredScaled(ctx, getMessage().getString(), textCx, y + h / 2f + 0.5f,
                fx ? 1f + 0.05f * hov : 1f, textColor, primary);
        if (fx) m.popMatrix();
    }
}
