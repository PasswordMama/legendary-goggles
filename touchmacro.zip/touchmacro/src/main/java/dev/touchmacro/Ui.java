package dev.touchmacro;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;

/** Drawing helpers for the "Rose Glass" look: rounded pills, glass panels, soft glow, smooth text. */
public final class Ui {
    private Ui() {}

    /** 0..1, multiplies every alpha (used for the open fade-in). */
    public static float fade = 1f;

    public static int a(int c) {
        int al = Math.round(((c >>> 24) & 255) * fade);
        return (al << 24) | (c & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((c1 >>> 24) & 255) + ((((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t));
        int r = (int) (((c1 >> 16) & 255) + ((((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t));
        int g = (int) (((c1 >> 8) & 255) + ((((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t));
        int b = (int) ((c1 & 255) + (((c2 & 255) - (c1 & 255)) * t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Frame-rate independent smoothing: moves cur toward target, rate ~ 10..25 feels snappy. */
    public static float approach(float cur, float target, float rate, float dt) {
        return cur + (target - cur) * (1f - (float) Math.exp(-rate * dt));
    }

    private static int inset(int i, int h, int r) {
        if (r <= 0) return 0;
        double d;
        if (i < r) d = r - i - 0.5;
        else if (i >= h - r) d = i - (h - r) + 0.5;
        else return 0;
        return (int) Math.round(r - Math.sqrt(Math.max(0, (double) r * r - d * d)));
    }

    private static int clampR(int w, int h, int r) { return Math.max(0, Math.min(r, Math.min(w, h) / 2)); }

    public static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = clampR(w, h, r);
        int col = a(color);
        // rows with the same corner inset are merged into one fill (far fewer draw calls)
        int start = 0, runIns = inset(0, h, r);
        for (int i = 1; i <= h; i++) {
            int ins = i < h ? inset(i, h, r) : -1;
            if (ins != runIns) {
                c.fill(x + runIns, y + start, x + w - runIns, y + i, col);
                start = i;
                runIns = ins;
            }
        }
    }

    public static void roundGradient(DrawContext c, int x, int y, int w, int h, int r, int top, int bottom) {
        r = clampR(w, h, r);
        int start = 0, runIns = inset(0, h, r);
        for (int i = 1; i <= h; i++) {
            int ins = i < h ? inset(i, h, r) : -1;
            if (ins != runIns) {
                float t0 = h <= 1 ? 0f : start / (float) (h - 1);
                float t1 = h <= 1 ? 0f : Math.min(1f, (i - 1) / (float) (h - 1));
                c.fillGradient(x + runIns, y + start, x + w - runIns, y + i,
                        a(lerp(top, bottom, t0)), a(lerp(top, bottom, t1)));
                start = i;
                runIns = ins;
            }
        }
    }

    public static void roundOutline(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = clampR(w, h, r);
        int col = a(color);
        int top = r, bot = h - r; // straight section [top, bot): drawn as two tall fills below
        for (int i = 0; i < h; i++) {
            if (i > 0 && i < h - 1 && i >= top && i < bot) continue;
            int ins = inset(i, h, r);
            if (i == 0 || i == h - 1) {
                c.fill(x + ins, y + i, x + w - ins, y + i + 1, col);
                continue;
            }
            int ref = i < r ? inset(i - 1, h, r) : inset(i + 1, h, r);
            int run = Math.max(1, ref - ins);
            c.fill(x + ins, y + i, x + ins + run, y + i + 1, col);
            c.fill(x + w - ins - run, y + i, x + w - ins, y + i + 1, col);
        }
        int lo = Math.max(top, 1), hi = Math.min(bot, h - 1);
        if (hi > lo) {
            c.fill(x, y + lo, x + 1, y + hi, col);
            c.fill(x + w - 1, y + lo, x + w, y + hi, col);
        }
    }

    /** Soft round glow made of stacked translucent discs. */
    public static void glow(DrawContext c, int cx, int cy, int radius, int rgb, int alphaPerLayer) {
        int layers = BindConfig.quality >= 2 ? 6 : 3;
        if (BindConfig.quality <= 0) return;
        for (int k = 0; k < layers; k++) {
            int rad = radius * (layers - k) / layers;
            roundRect(c, cx - rad, cy - rad, rad * 2, rad * 2, rad, ((alphaPerLayer * 6 / layers) << 24) | (rgb & 0xFFFFFF));
        }
    }

    // ---------- animated background ----------
    private static final int N_SPARK = 26;
    private static final float[] SX = new float[N_SPARK], SS = new float[N_SPARK], SP = new float[N_SPARK];
    private static final int[] SZ = new int[N_SPARK];
    static {
        java.util.Random rnd = new java.util.Random(1234);
        for (int i = 0; i < N_SPARK; i++) {
            SX[i] = rnd.nextFloat();
            SS[i] = 0.018f + rnd.nextFloat() * 0.03f; // screens per second
            SP[i] = rnd.nextFloat();
            SZ[i] = 2 + rnd.nextInt(3);
        }
    }

    public static void drawBackground(DrawContext c, int w, int h) {
        long ms = System.currentTimeMillis();
        double t = ms / 2600.0;
        // gradient slowly "breathes"
        float br = (float) (0.5 + 0.5 * Math.sin(ms / 3800.0));
        c.fillGradient(0, 0, w, h / 2, a(lerp(0xCC241636, 0xCC2E1A46, br)), a(lerp(0xCC5B2A5E, 0xCC6A2F6C, br)));
        c.fillGradient(0, h / 2, w, h, a(lerp(0xCC5B2A5E, 0xCC6A2F6C, br)), a(lerp(0xE0C8508A, 0xE0D85C9A, br)));
        if (BindConfig.quality <= 0) return; // Low: plain gradient only
        glow(c, (int) (w * 0.12 + Math.sin(t) * 18), (int) (h * 0.15 + Math.cos(t * 0.8) * 12), 90, 0xFF7EB6, 7);
        glow(c, (int) (w * 0.9 + Math.cos(t * 0.9) * 18), (int) (h * 0.9 + Math.sin(t) * 12), 80, 0x9B6BFF, 7);
        if (BindConfig.quality >= 2) glow(c, (int) (w * 0.55 + Math.sin(t * 0.6) * 30), (int) (h * 0.5 + Math.cos(t * 0.7) * 20), 70, 0xFFB3D9, 4);

        // drifting sparkles
        int sparks = BindConfig.quality >= 2 ? N_SPARK : 8;
        for (int i = 0; i < sparks; i++) {
            float prog = (float) (((ms / 1000.0) * SS[i] + SP[i]) % 1.0);
            int x = (int) (SX[i] * w + Math.sin(ms / 1400.0 + i * 1.7) * 9);
            int y = (int) (h * (1f - prog));
            float tw = 0.55f + 0.45f * (float) Math.sin(ms / 420.0 + i * 2.3);
            float edge = (float) Math.sin(prog * Math.PI);
            int al = (int) (70 * tw * edge);
            if (al < 4) continue;
            int s = SZ[i];
            roundRect(c, x, y, s, s, s / 2, (al << 24) | 0xFFE3F0);
        }
    }

    public static void panel(DrawContext c, int x, int y, int w, int h) {
        for (int k = BindConfig.quality <= 0 ? 1 : 3; k >= 1; k--) roundRect(c, x - k, y - k + 3, w + 2 * k, h + 2 * k, 18 + k, 0x14000000);
        roundRect(c, x, y, w, h, 16, 0x30FFFFFF);
        float pulse = (float) (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 1500.0));
        roundOutline(c, x, y, w, h, 16, lerp(0x55FFFFFF, 0x88FFC4E1, pulse));
    }

    // ---------- text (Poppins, soft shadow, optional smooth scaling) ----------
    private static void drawRaw(DrawContext c, Text t, int x, int y, int col) {
        var tr = MinecraftClient.getInstance().textRenderer;
        int sh = ((col >>> 24) * 0x40 / 255) << 24;
        if (BindConfig.quality > 0) c.drawText(tr, t, x, y + 1, sh, false); // soft drop shadow
        c.drawText(tr, t, x, y, col, false);
    }

    public static int width(String s, boolean bold) {
        return MinecraftClient.getInstance().textRenderer.getWidth(Fonts.ui(s, bold));
    }

    public static void left(DrawContext c, String s, int x, int y, int color, boolean bold) {
        int col = a(color);
        if ((col >>> 24) < 8) return;
        drawRaw(c, Fonts.ui(s, bold), x, y, col);
    }

    public static void left(DrawContext c, String s, int x, int y, int color) { left(c, s, x, y, color, false); }

    public static void centered(DrawContext c, String s, int cx, int y, int color, boolean bold) {
        int col = a(color);
        if ((col >>> 24) < 8) return;
        Text t = Fonts.ui(s, bold);
        int w = MinecraftClient.getInstance().textRenderer.getWidth(t);
        drawRaw(c, t, cx - w / 2, y, col);
    }

    public static void centered(DrawContext c, String s, int cx, int y, int color) { centered(c, s, cx, y, color, false); }

    /** Centered text that grows smoothly by `scale` around its own centre (used for hover/press). */
    public static void centeredScaled(DrawContext c, String s, float cx, float cy, float scale, int color, boolean bold) {
        int col = a(color);
        if ((col >>> 24) < 8) return;
        Text t = Fonts.ui(s, bold);
        int w = MinecraftClient.getInstance().textRenderer.getWidth(t);
        if (BindConfig.quality <= 0 || Math.abs(scale - 1f) < 0.004f) {
            drawRaw(c, t, Math.round(cx) - w / 2, Math.round(cy) - 4, col);
            return;
        }
        Matrix3x2fStack m = c.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        m.scale(scale, scale);
        drawRaw(c, t, -w / 2, -4, col);
        m.popMatrix();
    }
}
