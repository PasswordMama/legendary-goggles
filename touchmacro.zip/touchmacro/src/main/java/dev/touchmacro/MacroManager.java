package dev.touchmacro;

import com.google.gson.Gson;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public final class MacroManager {
    public enum State { IDLE, RECORDING, PLAYING }

    public static State state = State.IDLE;
    public static boolean loop = false;
    public static MacroData current = null;
    public static String currentName = "";

    private static final Gson GSON = new Gson();

    // key bit layout (see MacroData)
    private static final int B_ATTACK = 7, B_USE = 8, B_DROP = 9, B_SWAP = 10;
    private static final int EV_CHAT = 1, EV_CMD = 2, EV_CLICK_PLAYER = 3, EV_CLICK_CONT = 4,
            EV_OPEN_INV = 5, EV_CLOSE = 6;
    private static final float NO_LOOK = 9999f;

    private static final class Frame { int f; float yaw, pitch; int slot; }
    private static final class Ev { int tick, type, a, b, c; String s = ""; }

    private static final List<Frame> rec = new ArrayList<>();
    private static final List<Ev> evRec = new ArrayList<>();
    private static boolean wasHandled = false;

    private static int playIndex = 0;
    private static int evIdx = 0;
    private static int blockTicks = 0;
    private static int prevFlags = 0;
    /** Fractional frame counter that makes playback speed adjustable (see getSpeed). */
    private static float playAccum = 1f;
    private static boolean speedDirty = false;

    // ---- wander (random 2-block walk out and back every N loops) ----
    private static final double WANDER_DIST = 2.0;
    private static int loopCount = 0;
    private static int wanderPhase = 0; // 0 none, 1 going out, 2 coming back
    private static int wanderTicks = 0;
    private static double sx, sz, tx, tz;

    private MacroManager() {}

    private static KeyBinding[] keys(GameOptions o) {
        return new KeyBinding[]{o.forwardKey, o.backKey, o.leftKey, o.rightKey,
                o.jumpKey, o.sneakKey, o.sprintKey, o.attackKey, o.useKey,
                o.dropKey, o.swapHandsKey};
    }

    private static int flagMask() {
        int m = 0;
        if (BindConfig.on(BindConfig.T_MOVE)) m |= 0b1111111;
        if (BindConfig.on(BindConfig.T_MINE)) m |= 1 << B_ATTACK;
        if (BindConfig.on(BindConfig.T_USE)) m |= 1 << B_USE;
        if (BindConfig.on(BindConfig.T_INV)) m |= (1 << B_DROP) | (1 << B_SWAP);
        return m;
    }

    /** Ticks only run while no screen is open, or (if inventory is on) a container/inventory is open. */
    private static boolean canTick(MinecraftClient c) {
        if (c.currentScreen == null) return true;
        return BindConfig.on(BindConfig.T_INV) && c.currentScreen instanceof HandledScreen<?>;
    }

    private static void msg(MinecraftClient c, String s) {
        if (c.player != null) c.player.sendMessage(Text.literal(s), true);
    }

    private static void releaseAll(MinecraftClient c) {
        for (KeyBinding k : keys(c.options)) k.setPressed(false);
    }

    // ---------- playback speed (stored inside each macro) ----------
    public static float getSpeed() {
        if (current == null || current.speed <= 0f) return 1f;
        return Math.max(PinkSlider.MIN, Math.min(PinkSlider.MAX, current.speed));
    }

    /** Changes the loaded macro's speed. It is written to its file by flushSpeed(). */
    public static void setSpeed(float v) {
        if (current == null) return;
        v = Math.round(Math.max(PinkSlider.MIN, Math.min(PinkSlider.MAX, v)) * 100f) / 100f;
        if (current.speed != v) {
            current.speed = v;
            speedDirty = true;
        }
    }

    /** If the loaded macro is already saved on disk, store its new speed there too. */
    public static void flushSpeed() {
        if (!speedDirty) return;
        speedDirty = false;
        if (current != null && !currentName.isEmpty() && !currentName.startsWith("(")) save(currentName);
    }

    // ---------- recording ----------
    public static void startRecording(MinecraftClient c) {
        if (c.player == null) return;
        stopAll(c);
        rec.clear();
        evRec.clear();
        wasHandled = c.currentScreen instanceof HandledScreen<?>;
        state = State.RECORDING;
        msg(c, "● Recording...");
    }

    public static void stopRecording(MinecraftClient c) {
        if (state != State.RECORDING) return;
        state = State.IDLE;
        MacroData d = new MacroData();
        int n = rec.size();
        d.flags = new int[n]; d.yaw = new float[n]; d.pitch = new float[n]; d.slot = new int[n];
        for (int i = 0; i < n; i++) {
            Frame f = rec.get(i);
            d.flags[i] = f.f; d.yaw[i] = f.yaw; d.pitch[i] = f.pitch; d.slot[i] = f.slot;
        }
        int m = evRec.size();
        d.evTick = new int[m]; d.evType = new int[m]; d.evA = new int[m];
        d.evB = new int[m]; d.evC = new int[m]; d.evS = new String[m];
        for (int i = 0; i < m; i++) {
            Ev e = evRec.get(i);
            d.evTick[i] = e.tick; d.evType[i] = e.type; d.evA[i] = e.a;
            d.evB[i] = e.b; d.evC[i] = e.c; d.evS[i] = e.s;
        }
        rec.clear();
        evRec.clear();
        current = d;
        currentName = "(unsaved)";
        msg(c, "Recorded " + n + " ticks, " + m + " events. Open the GUI to save.");
    }

    private static void addEv(int type, int a, int b, int cc, String s) {
        Ev e = new Ev();
        e.tick = rec.size();
        e.type = type; e.a = a; e.b = b; e.c = cc; e.s = s == null ? "" : s;
        evRec.add(e);
    }

    /** Called from the clickSlot mixin. */
    public static void onClick(int syncId, int slotId, int button, SlotActionType type) {
        if (state != State.RECORDING || !BindConfig.on(BindConfig.T_INV)) return;
        addEv(syncId == 0 ? EV_CLICK_PLAYER : EV_CLICK_CONT, slotId, button, type.ordinal(), "");
    }

    /** Called from Fabric's send-message events (not fired for messages we send during replay). */
    public static void onChat(String text, boolean command) {
        if (state != State.RECORDING) return;
        if (command) {
            if (!BindConfig.on(BindConfig.T_CMD)) return;
            String t = text.startsWith("/") ? text.substring(1) : text;
            if (t.equals("macro") || t.startsWith("macro ")) return;
            addEv(EV_CMD, 0, 0, 0, t);
        } else {
            if (!BindConfig.on(BindConfig.T_CHAT)) return;
            addEv(EV_CHAT, 0, 0, 0, text);
        }
    }

    // ---------- playback ----------
    public static void startPlayback(MinecraftClient c) {
        if (c.player == null || current == null || current.length() == 0) {
            msg(c, "Nothing to play. Record or load a macro first.");
            return;
        }
        stopAll(c);
        playIndex = 0;
        evIdx = 0;
        blockTicks = 0;
        prevFlags = 0;
        loopCount = 0;
        wanderPhase = 0;
        playAccum = Math.max(0f, 1f - getSpeed());
        state = State.PLAYING;
    }

    public static void stopPlayback(MinecraftClient c) {
        if (state != State.PLAYING) return;
        state = State.IDLE;
        wanderPhase = 0;
        releaseAll(c);
        msg(c, "Playback stopped.");
    }

    public static void stopAll(MinecraftClient c) {
        if (state == State.RECORDING) stopRecording(c);
        else if (state == State.PLAYING) stopPlayback(c);
    }

    /** @return true when the event is finished, false when it must wait (e.g. menu not open yet). */
    private static boolean execEvent(MinecraftClient c, ClientPlayerEntity p, int i) {
        int type = current.evType[i];
        switch (type) {
            case EV_CHAT -> {
                if (BindConfig.on(BindConfig.T_CHAT)) p.networkHandler.sendChatMessage(current.evS[i]);
                return true;
            }
            case EV_CMD -> {
                String cmd = current.evS[i];
                if (BindConfig.on(BindConfig.T_CMD) && !(cmd.equals("macro") || cmd.startsWith("macro ")))
                    p.networkHandler.sendChatCommand(cmd);
                return true;
            }
            case EV_OPEN_INV -> {
                if (BindConfig.on(BindConfig.T_INV) && !(c.currentScreen instanceof InventoryScreen))
                    c.setScreen(new InventoryScreen(p));
                return true;
            }
            case EV_CLOSE -> {
                if (BindConfig.on(BindConfig.T_INV) && c.currentScreen instanceof HandledScreen<?>)
                    p.closeHandledScreen();
                return true;
            }
            case EV_CLICK_PLAYER, EV_CLICK_CONT -> {
                if (!BindConfig.on(BindConfig.T_INV)) return true;
                ScreenHandler h = p.currentScreenHandler;
                if (type == EV_CLICK_CONT && h == p.playerScreenHandler) return false; // wait for menu
                int slot = current.evA[i];
                if (slot >= h.slots.size()) return true;
                SlotActionType[] types = SlotActionType.values();
                int at = current.evC[i];
                if (at < 0 || at >= types.length) return true;
                if (c.interactionManager != null)
                    c.interactionManager.clickSlot(h.syncId, slot, current.evB[i], types[at], p);
                return true;
            }
            default -> { return true; }
        }
    }

    // ---------- tick hooks ----------
    public static void startTick(MinecraftClient c) {
        if (state != State.PLAYING) return;
        ClientPlayerEntity p = c.player;
        if (p == null) { state = State.IDLE; return; }
        if (c.currentScreen != null && !(c.currentScreen instanceof HandledScreen<?>)) return; // paused by a menu

        if (wanderPhase != 0) { wanderTick(c, p); return; }

        // Speed: every tick adds `speed` to a frame counter; each whole 1.0 plays one recorded frame.
        // 0.5x -> a frame every 2 ticks (keys stay held, look is blended); 2x -> two frames per tick.
        float spd = getSpeed();
        playAccum += spd;
        int guard = 0;
        while (playAccum >= 1f && guard++ < 8) {
            playAccum -= 1f;
            if (!stepFrame(c, p)) {
                playAccum = Math.min(playAccum, 1f); // blocked / wandering / stopped: don't build a backlog
                return;
            }
        }
        if (playAccum > 1f) playAccum = 1f;
        if (spd < 1f) blendLook(p);
    }

    /** Plays one recorded frame. @return false if this tick must stop here (waiting, wander, finished). */
    private static boolean stepFrame(MinecraftClient c, ClientPlayerEntity p) {
        // timed events (chat, commands, inventory clicks...) due at this frame
        while (evIdx < current.evCount() && current.evTick[evIdx] <= playIndex) {
            if (execEvent(c, p, evIdx)) {
                evIdx++;
                blockTicks = 0;
            } else if (++blockTicks > 200) { // menu never opened: skip this event
                evIdx++;
                blockTicks = 0;
            } else {
                releaseAll(c);
                prevFlags = 0;
                return false; // wait here
            }
        }

        if (playIndex >= current.length()) {
            if (loop) {
                playIndex = 0;
                evIdx = 0;
                loopCount++;
                int n = BindConfig.wanderEvery;
                if (n > 0 && loopCount % n == 0) {
                    beginWander(c, p);
                    wanderTick(c, p);
                    return false;
                }
            } else { stopPlayback(c); return false; }
        }

        int i = playIndex++;
        int f = current.flags[i] & flagMask();
        KeyBinding[] ks = keys(c.options);
        for (int b = 0; b < ks.length; b++) {
            boolean down = ((f >> b) & 1) != 0;
            boolean was = ((prevFlags >> b) & 1) != 0;
            ks[b].setPressed(down);
            if (down && !was && (b == B_ATTACK || b == B_USE || b == B_DROP || b == B_SWAP)) {
                // registers a "click" so single hits/placements/drops work, not only held input
                KeyBinding.onKeyPressed(InputUtil.fromTranslationKey(ks[b].getBoundKeyTranslationKey()));
            }
        }
        prevFlags = f;
        if (BindConfig.on(BindConfig.T_LOOK) && current.yaw[i] < NO_LOOK - 1) {
            p.setYaw(current.yaw[i]);
            p.setPitch(current.pitch[i]);
        }
        int s = current.slot[i];
        if (BindConfig.on(BindConfig.T_HOTBAR) && s >= 0 && s < 9) p.getInventory().setSelectedSlot(s);
        if (i % 20 == 0) {
            msg(c, "▶ Playing " + i + "/" + current.length() + (loop ? " (loop)" : "")
                    + (getSpeed() != 1f ? "  " + PinkSlider.format(getSpeed()) : ""));
        }
        return true;
    }

    /** Slow motion: glide the camera between the last played frame and the next one. */
    private static void blendLook(ClientPlayerEntity p) {
        if (!BindConfig.on(BindConfig.T_LOOK)) return;
        int a = playIndex - 1, b = playIndex;
        if (a < 0 || b >= current.length()) return;
        if (current.yaw[a] >= NO_LOOK - 1 || current.yaw[b] >= NO_LOOK - 1) return;
        float t = Math.max(0f, Math.min(1f, playAccum));
        p.setYaw(current.yaw[a] + MathHelper.wrapDegrees(current.yaw[b] - current.yaw[a]) * t);
        p.setPitch(current.pitch[a] + (current.pitch[b] - current.pitch[a]) * t);
    }

    private static void beginWander(MinecraftClient c, ClientPlayerEntity p) {
        sx = p.getX();
        sz = p.getZ();
        double a = Math.random() * Math.PI * 2;
        tx = sx + Math.cos(a) * WANDER_DIST;
        tz = sz + Math.sin(a) * WANDER_DIST;
        wanderPhase = 1;
        wanderTicks = 0;
        releaseAll(c);
        prevFlags = 0;
    }

    private static void endWander(MinecraftClient c) {
        wanderPhase = 0;
        wanderTicks = 0;
        releaseAll(c);
        prevFlags = 0;
        playIndex = 0;
        evIdx = 0;
        playAccum = Math.max(0f, 1f - getSpeed());
    }

    private static void wanderTick(MinecraftClient c, ClientPlayerEntity p) {
        wanderTicks++;
        KeyBinding[] ks = keys(c.options);
        for (KeyBinding k : ks) k.setPressed(false);

        double gx = wanderPhase == 1 ? tx : sx;
        double gz = wanderPhase == 1 ? tz : sz;
        double dx = gx - p.getX(), dz = gz - p.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);

        if (wanderTicks > 300) { // stuck/blocked: give up and carry on
            endWander(c);
            return;
        }

        if (dist < 0.12) {
            if (wanderPhase == 1) {
                wanderPhase = 2;
                wanderTicks = 0;
                return;
            }
            // back home: snap onto the exact start spot and resume the macro
            p.setPosition(sx, p.getY(), sz);
            p.setVelocity(0, p.getVelocity().y, 0);
            endWander(c);
            return;
        }

        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        p.setYaw(yaw);
        p.setPitch(0f);
        ks[0].setPressed(true);                          // forward
        if (dist < 0.8) ks[5].setPressed(true);          // sneak to slow down near target
        if (p.horizontalCollision && p.isOnGround()) ks[4].setPressed(true); // hop over 1-block steps
        if (wanderTicks % 20 == 0) msg(c, "↔ Wandering " + (wanderPhase == 1 ? "out" : "back"));
    }

    public static void endTick(MinecraftClient c) {
        if (state != State.RECORDING) return;
        ClientPlayerEntity p = c.player;
        if (p == null) { stopRecording(c); return; }

        // inventory / menu open + close events
        boolean handled = c.currentScreen instanceof HandledScreen<?>;
        if (BindConfig.on(BindConfig.T_INV)) {
            if (handled && !wasHandled && c.currentScreen instanceof InventoryScreen)
                addEv(EV_OPEN_INV, 0, 0, 0, "");
            else if (!handled && wasHandled)
                addEv(EV_CLOSE, 0, 0, 0, "");
        }
        wasHandled = handled;

        if (!canTick(c)) return; // don't record while chat / other menus are open

        KeyBinding[] ks = keys(c.options);
        Frame fr = new Frame();
        for (int b = 0; b < ks.length; b++) if (ks[b].isPressed()) fr.f |= 1 << b;
        fr.f &= flagMask();
        boolean look = BindConfig.on(BindConfig.T_LOOK);
        fr.yaw = look ? p.getYaw() : NO_LOOK;
        fr.pitch = look ? p.getPitch() : 0f;
        fr.slot = BindConfig.on(BindConfig.T_HOTBAR) ? p.getInventory().getSelectedSlot() : -1;
        rec.add(fr);
        if (rec.size() % 20 == 0) msg(c, "● REC " + rec.size() + " ticks, " + evRec.size() + " events");
    }

    // ---------- storage ----------
    private static Path dir() {
        return FabricLoader.getInstance().getConfigDir().resolve("touchmacro").resolve("macros");
    }

    public static String sanitize(String n) {
        String s = n == null ? "" : n.replaceAll("[^A-Za-z0-9_-]", "_");
        return s.isEmpty() ? "macro" : s;
    }

    public static boolean save(String name) {
        if (current == null || current.length() == 0) return false;
        try {
            name = sanitize(name);
            Files.createDirectories(dir());
            Files.writeString(dir().resolve(name + ".json"), GSON.toJson(current));
            currentName = name;
            speedDirty = false;
            return true;
        } catch (Exception e) {
            System.err.println("[TouchMacro] save failed: " + e);
            return false;
        }
    }

    public static boolean load(String name) {
        try {
            Path f = dir().resolve(sanitize(name) + ".json");
            MacroData d = GSON.fromJson(Files.readString(f), MacroData.class);
            if (d == null || d.length() == 0) return false;
            // old (v1) macros have 9-bit flags and no look sentinel; they still play fine
            if (d.speed <= 0f) d.speed = 1f;
            speedDirty = false;
            current = d;
            currentName = sanitize(name);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean delete(String name) {
        try {
            return Files.deleteIfExists(dir().resolve(sanitize(name) + ".json"));
        } catch (Exception e) {
            return false;
        }
    }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try {
            if (!Files.isDirectory(dir())) return out;
            try (Stream<Path> s = Files.list(dir())) {
                s.map(p -> p.getFileName().toString())
                        .filter(n -> n.endsWith(".json"))
                        .forEach(n -> out.add(n.substring(0, n.length() - 5)));
            }
        } catch (Exception ignored) {}
        Collections.sort(out);
        return out;
    }
}
