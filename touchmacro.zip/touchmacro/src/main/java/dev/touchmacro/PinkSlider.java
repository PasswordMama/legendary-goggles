package dev.touchmacro;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import org.joml.Matrix3x2fStack;

/**
 * Speed slider. Left half = slower than recorded (0.1x..1x), right half = faster (1x..5x),
 * so the middle is always "as recorded". Tap or drag anywhere on the bar.
 */
public class PinkSlider extends ClickableWidget {
    public interface Listener { void changed(float value); }

    public static final float MIN = 0.1f, MAX = 5f;

    private float value = 1f;
    private float shown = 0.5f;   // eased knob position 0..1
    private float hov = 0f;
    private long lastNs = System.nanoTime();
    private final Listener listener;

    public PinkSlider(int x, int y, int w, int h, Listener listener) {
        super(x, y, w, h, Text.literal("Speed"));
        this.listener = listener;
    }

    public static float toT(float v) {
        v = Math.max(MIN, Math.min(MAX, v));
        return v <= 1f ? (v - MIN) / (1f - MIN) * 0.5f : 0.5f + (v - 1f) / (MAX - 1f) * 0.5f;
    }

    public static float fromT(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float v = t <= 0.5f ? MIN + t / 0.5f * (1f - MIN) : 1f + (t - 0.5f) / 0.5f * (MAX - 1f);
        if (Math.abs(v - 1f) < 0.05f) return 1f;                       // magnet at "as recorded"
        v = v < 1f ? Math.round(v * 20f) / 20f : Math.round(v * 10f) / 10f; // 0.05 steps below 1, 0.1 above
        return Math.max(MIN, Math.min(MAX, v));
    }

    public float getValue() { return value; }

    /** Set from outside (load, +/- buttons, reset). */
    public void setValue(float v) {
        value = Math.max(MIN, Math.min(MAX, Math.round(v * 100f) / 100f));
    }

    private void fromMouse(double mx) {
        float x0 = getX() + 9f, x1 = getX() + getWidth() - 9f;
        float t = (float) ((mx - x0) / Math.max(1f, x1 - x0));
        float v = fromT(t);
        if (v != value) {
            value = v;
            listener.changed(value);
        }
    }

    @Override
    public void onClick(Click click, boolean doubled) { fromMouse(click.x()); }

    @Override
    public void onDrag(Click click, double offsetX, double offsetY) { fromMouse(click.x()); }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        this.appendDefaultNarrations(builder);
    }

    private static float fmtV = -1f;
    private static String fmtS = "";

    public static String format(float v) {
        if (v == fmtV) return fmtS;
        fmtV = v;
        fmtS = format0(v);
        return fmtS;
    }

    private static String format0(float v) {
        String s = String.format(java.util.Locale.ROOT, "%.2f", v);
        if (s.endsWith("0")) s = s.substring(0, s.length() - 1);
        return s + "x";
    }

    @Override
    public void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long nowNs = System.nanoTime();
        float dt = Math.min(0.08f, (nowNs - lastNs) / 1_000_000_000f);
        lastNs = nowNs;
        hov = Ui.approach(hov, (this.isHovered() && this.active) ? 1f : 0f, 14f, dt);
        shown = Ui.approach(shown, toT(value), 20f, dt);

        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        int r = h / 2;
        float tx0 = x + 9f, tx1 = x + w - 9f;
        int kx = Math.round(tx0 + (tx1 - tx0) * shown);

        Matrix3x2fStack m = ctx.getMatrices();
        float cx = x + w / 2f, cy = y + h / 2f;
        boolean fx = BindConfig.quality >= 1;
        if (fx) {
            float sc = 1f + 0.02f * hov;
            m.pushMatrix();
            m.translate(cx, cy);
            m.scale(sc, sc);
            m.translate(-cx, -cy);
        }

        // track
        Ui.roundRect(ctx, x, y, w, h, r, Ui.lerp(0x29FFFFFF, 0x3DFFFFFF, hov));
        Ui.roundOutline(ctx, x, y, w, h, r, Ui.lerp(0x4DFFFFFF, 0x99FFFFFF, hov));
        // fill up to the knob
        int fw = Math.max(h, kx - x + 8);
        if (this.active) {
            Ui.roundGradient(ctx, x, y, Math.min(w, fw), h, r, 0xCCE23A85, 0xCCC71F6E);
            // "as recorded" tick in the middle
            int mid = Math.round(tx0 + (tx1 - tx0) * 0.5f);
            Ui.roundRect(ctx, mid, y + h - 4, 1, 3, 0, 0x88FFFFFF);
        }
        // label
        String label = this.active ? "Speed  " + format(value) : "Speed (load a macro)";
        Ui.centeredScaled(ctx, label, cx, cy + 0.5f, 1f, this.active ? 0xFFFFFFFF : 0x88FFFFFF, true);
        // knob
        if (this.active) {
            int ks = 10 + Math.round(2 * hov);
            Ui.roundRect(ctx, kx - ks / 2 - 2, y + h / 2 - ks / 2 - 1, ks + 4, ks + 4, (ks + 4) / 2, 0x33FF9CCB);
            Ui.roundRect(ctx, kx - ks / 2, y + h / 2 - ks / 2, ks, ks, ks / 2, 0xFFFFFFFF);
            Ui.roundRect(ctx, kx - 2, y + h / 2 - 2, 4, 4, 2, 0xFFD62A74);
        }
        if (fx) m.popMatrix();
    }
}
